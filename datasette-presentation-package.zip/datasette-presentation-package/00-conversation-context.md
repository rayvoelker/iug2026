# Conversation Context & Research Summary

## Who Is This For?

Ray Voelker — works at the Cincinnati & Hamilton County Public Library (CHPL). He's preparing **two 15-minute presentations** about his love of Datasette and how he uses it at CHPL. He has given similar talks before (PyOhio 2021 Thunder Talk, IUG 2022). He wants to feature both the **Newsdex project** and the **collection-analysis platform**.

## The Two Projects

### 1. Collection Analysis Platform
- **Live instance:** https://collection-analysis.cincy.pl/
- **Source code:** https://github.com/cincinnatilibrary/collection-analysis
- **What it is:** A Datasette instance serving snapshots of CHPL's entire physical collection, exported from the Sierra ILS (Innovative Interfaces / Clarivate). Contains millions of item records with barcodes, locations, formats, statuses, circulation data, call numbers, prices, etc.
- **Architecture:** Sierra PostgreSQL → SQL export → Python/sqlite-utils → SQLite databases → Datasette behind Apache on a $5/month Digital Ocean VPS
- **Key tables:** `item` (the main table with columns like item_record_num, bib_record_num, barcode, location_code, item_format, item_status_code, checkout_date, due_date, checkout_total, item_callnumber, price_cents), plus supporting tables and views
- **Hosting guide:** https://ils-underground.github.io/python_datasette_vps.html (detailed step-by-step for Digital Ocean + Ubuntu + Apache + Datasette)
- **Previous talks:**
  - PyOhio 2021 Thunder Talk: https://www.pyohio.org/2021/program/talks/i-datasette-an-open-source-multi-tool-for-exploring-and-publishing-data/
  - IUG 2022: "Collection Analysis for $5 a Month. CHEAP!" — https://forum.innovativeusers.org/t/collection-analysis-for-5-a-month-cheap/503

### 2. Newsdex Project
- **Newsdex (live search):** https://newsdex.cincinnatilibrary.org/
- **GitHub repo:** https://github.com/cincinnatilibrary/newsdex (contains MARC export, Jupyter notebooks for conversion)
- **What it is:** Newsdex is a newspaper article index created and maintained by CHPL staff since 1927. It provides citations (title, date, newspaper, page, column, image indicator) for articles in Cincinnati newspapers (Enquirer, Post, Herald, Cincinnati Magazine, Business Courier, Downtowner). Coverage reaches back to the early 1800s.
- **The data pipeline:** MARC records → pymarc (Python) → field mapping/cleanup → sqlite-utils → SQLite → Datasette
- **Key notebooks in the repo:**
  - `marc-to-sqlite.ipynb` — converts MARC to SQLite
  - `newsdex-convert.ipynb` — record conversion logic
  - `notes_and_mappings.ipynb` — documents MARC field → column mappings (the "translation layer")
- **MARC export file:** `2023-01-24_newsdex-full-marc-export.zip` (in the repo)
- **IMPORTANT CHPL blog post (Ray wants this featured prominently):** https://chpl.org/blogs/post/newsdex-upgrade/ — "CHPL's Newsdex Tool Just Made Researching Local History Even Easier" (May 2023). Contains:
  - History of Newsdex starting in 1927 with Head Librarian Chalmers Hadley
  - Quote: "news reports of major local happenings would be matters of history some day and that the proper indexing of such items in time would be valuable"
  - Photo of Chalmers Hadley
  - Photo of the physical card catalog
  - Screenshot of a Newsdex search result ("1937 flood" example)
  - Video tutorial on basic Newsdex searching
  - Timeline: 1927 card catalog → 65 years of hand-typed cards → 1992 digitization → present

## About CHPL
- One of the busiest public library systems in the US
- ~9.6 million volumes (13th largest, 2nd largest public library collection)
- 41 locations across Hamilton County
- Over 21 million items circulated annually (pre-pandemic)
- Downtown Main Library circulates 4M+ items/year (most of any single location in the US)
- Runs Sierra ILS
- Wikipedia: https://en.wikipedia.org/wiki/Cincinnati_and_Hamilton_County_Public_Library

## About Datasette
- Created by Simon Willison (co-creator of Django)
- Open-source tool for exploring and publishing data on top of SQLite
- Website: https://datasette.io/
- Docs: https://docs.datasette.io/
- Key features: faceted browsing, full-text search, JSON API, CSV export, SQL editor, 100+ plugins
- Ecosystem tools: sqlite-utils, csvs-to-sqlite, db-to-sqlite, Datasette Lite (WebAssembly)
- Recent developments (2025-2026): Datasette 1.0 alpha series, datasette-plot, datasette-showboat, NICAR 2026 workshop using Datasette with coding agents

## Ray's Online Presence
- GitHub: https://github.com/rayvoelker
- Presentations page: https://rayvoelker.github.io/
- CHPL GitHub orgs: https://github.com/cincinnatilibrary and https://github.com/plch

## Key Design Decisions
- Ray wants MORE material than fits in 15 minutes each — he'll edit down later
- Both presentations should have detailed slide-by-slide outlines with speaker notes, visual suggestions, and resource links
- The CHPL blog post about Newsdex (https://chpl.org/blogs/post/newsdex-upgrade/) should be featured prominently in the Newsdex presentation
- Output format: Markdown
- Presentation 1 is the broad "what and why" (collection analysis + Datasette intro)
- Presentation 2 is the deep dive (Newsdex history + MARC conversion pipeline)
- If delivered at the same event, Talk 1 is accessible to general audiences, Talk 2 rewards technical attendees
