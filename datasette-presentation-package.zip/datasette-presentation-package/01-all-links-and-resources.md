# All Links & Resources (Quick Reference)

## Ray's Projects & Presentations
- Collection Analysis (live): https://collection-analysis.cincy.pl/
- Collection Analysis repo: https://github.com/cincinnatilibrary/collection-analysis
- Newsdex (live search): https://newsdex.cincinnatilibrary.org/
- Newsdex repo (MARC data + notebooks): https://github.com/cincinnatilibrary/newsdex
- PyOhio 2021 Thunder Talk: https://www.pyohio.org/2021/program/talks/i-datasette-an-open-source-multi-tool-for-exploring-and-publishing-data/
- IUG 2022 Talk: https://forum.innovativeusers.org/t/collection-analysis-for-5-a-month-cheap/503
- VPS Hosting Guide: https://ils-underground.github.io/python_datasette_vps.html
- Ray's GitHub: https://github.com/rayvoelker
- Ray's presentations page: https://rayvoelker.github.io/
- CHPL GitHub orgs: https://github.com/cincinnatilibrary / https://github.com/plch

## CHPL Resources
- **CHPL Blog Post (MUST FEATURE):** https://chpl.org/blogs/post/newsdex-upgrade/
- CHPL website: https://chpl.org/
- CHPL Genealogy & Local History: https://chpl.org/genealogy-history/
- CHPL Research Databases: https://chpl.org/online-resources/
- CHPL History databases page: https://chpl.org/resources/history/
- CHPL Services: https://chpl.org/services/
- CHPL Wikipedia: https://en.wikipedia.org/wiki/Cincinnati_and_Hamilton_County_Public_Library

## Datasette Ecosystem
- Datasette: https://datasette.io/
- Datasette Documentation: https://docs.datasette.io/
- Datasette Lite (browser-only): https://lite.datasette.io/
- sqlite-utils: https://sqlite-utils.datasette.io/
- Datasette tools directory: https://datasette.io/tools
- Datasette plugins directory: https://datasette.io/plugins
- Datasette tutorials: https://datasette.io/tutorials
- Datasette for search: https://datasette.io/for/search
- Datasette for exploratory analysis: https://datasette.io/for/exploratory-analysis
- Datasette GitHub: https://github.com/simonw/datasette
- Datasette deployment docs: https://docs.datasette.io/en/stable/deploying.html
- Datasette facets docs: https://docs.datasette.io/en/stable/facets.html
- Datasette FTS docs: https://docs.datasette.io/en/stable/full_text_search.html
- Datasette plugins docs: https://docs.datasette.io/en/stable/plugins.html

## Simon Willison
- Blog: https://simonwillison.net/
- Newsletter (Substack): https://simonw.substack.com/
- Datasette Newsletter: https://datasette.substack.com/
- Datasette Cloud Blog: https://www.datasette.cloud/blog/
- GitHub: https://github.com/simonw

## Python Libraries
- pymarc: https://pypi.org/project/pymarc/
- sqlite-utils (PyPI): https://pypi.org/project/sqlite-utils/

## MARC Standards
- Library of Congress MARC: https://www.loc.gov/marc/
- LOC MARC Distribution Services: https://www.loc.gov/cds/products/marcDist.php

## Sierra ILS Community
- Sierra SQL queries (Jeremy Goldstein): https://github.com/jmgold/SQL-Queries
- ILS Underground docs: https://ils-underground.github.io/
- Sierra ILS GitHub topic: https://github.com/topics/sierra-ils
