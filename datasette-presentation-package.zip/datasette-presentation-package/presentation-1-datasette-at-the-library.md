# Presentation 1: Datasette at the Library — From ILS Snapshots to a $5/Month Analysis Platform

**Target Length:** ~15 minutes (with extra material to edit down)
**Audience:** Library technologists, ILS administrators, data-curious library staff, Python/open-source enthusiasts
**Prior Art:** [PyOhio 2021 Thunder Talk](https://www.pyohio.org/2021/program/talks/i-datasette-an-open-source-multi-tool-for-exploring-and-publishing-data/), [IUG 2022: "Collection Analysis for $5 a Month. CHEAP!"](https://forum.innovativeusers.org/t/collection-analysis-for-5-a-month-cheap/503)

---

## Slide-by-Slide Outline

---

### SLIDE 1 — Title Slide

**Title:** I ❤️ Datasette: From ILS Snapshots to a $5/Month Analysis Platform

**Subtitle:** How the Cincinnati & Hamilton County Public Library uses open-source tools to put collection data in everyone's hands

**Visual:** CHPL logo + Datasette logo side by side. Consider a background image of the Main Library building or the iconic interior.

**Speaker Notes:**
- Introduce yourself: name, role at CHPL, how long you've been working with library data
- Mention this is an updated/expanded version of talks you've given at PyOhio 2021 and IUG 2022
- Frame the talk: "This is the story of how a free tool and a $5 server changed the way our staff interacts with data"

---

### SLIDE 2 — The Problem: Data Locked Behind the ILS

**Title:** Your Data Is Trapped

**Visual:** A stylized diagram or illustration showing data locked inside a vault or behind a wall labeled "ILS." On one side: staff members with question marks over their heads. On the other: rows and rows of data they can't easily access.

**Content/Talking Points:**
- Libraries sit on enormous amounts of structured data — item records, circulation stats, bib records, patron activity
- That data lives inside ILS systems (like Sierra) that weren't designed for flexible, ad-hoc analysis
- Staff who need answers end up:
  - Filing tickets with IT
  - Waiting for canned reports from the vendor
  - Exporting CSVs and wrestling with Excel
  - Or just... not getting the answers they need
- The people who know the collection best (branch managers, collection development librarians, subject specialists) often have the least direct access to the data

**Speaker Notes:**
- Use a concrete example: "A branch manager wants to know how many juvenile graphic novels at their location haven't circulated in 2 years. How long does that take in your current system?"
- This isn't a Sierra-specific problem — it's universal across ILS platforms

---

### SLIDE 3 — What If There Were a Better Way?

**Title:** What If You Could Just... Explore It?

**Visual:** Screenshot of the collection-analysis Datasette instance at `collection-analysis.cincy.pl` — the home page showing multiple database snapshots. If possible, an animated GIF showing someone clicking through facets.

**Content/Talking Points:**
- What if non-technical staff could:
  - Browse the entire collection in a web browser
  - Filter by location, format, status, date — instantly
  - Run pre-built queries without writing SQL
  - Export results to CSV for their own analysis
  - Access a JSON API for more advanced use
- That's exactly what we built — and it costs $5/month to run

**Links/Resources:**
- Live instance: [https://collection-analysis.cincy.pl/](https://collection-analysis.cincy.pl/)
- Source code: [https://github.com/cincinnatilibrary/collection-analysis](https://github.com/cincinnatilibrary/collection-analysis)

---

### SLIDE 4 — Enter Datasette

**Title:** Datasette: An Open-Source Multi-Tool for Exploring and Publishing Data

**Visual:** The Datasette logo prominently displayed. Below it, a simple diagram: `SQLite Database → Datasette → Web UI + JSON API`. Consider showing Simon Willison's own description/tagline.

**Content/Talking Points:**
- Created by Simon Willison (co-creator of Django, former Guardian developer, JSK Fellow at Stanford)
- Datasette takes any SQLite database and instantly gives you:
  - A browsable web interface
  - Faceted search and filtering
  - Full-text search
  - A JSON API for every table and query
  - CSV export
  - SQL query editor
  - A plugin ecosystem with 100+ plugins
- Designed for: data journalists, museum curators, archivists, local governments, researchers
- **Key insight: Libraries are exactly the kind of institution Datasette was built for**
- Read-only by default — safe to hand to anyone

**Links/Resources:**
- Datasette: [https://datasette.io/](https://datasette.io/)
- Datasette documentation: [https://docs.datasette.io/](https://docs.datasette.io/)
- Simon Willison's blog: [https://simonwillison.net/](https://simonwillison.net/)

**Speaker Notes:**
- Emphasize that Datasette is NOT a database — it's a presentation and exploration layer on top of SQLite
- SQLite is the most widely deployed database in the world (it's on every smartphone, in every browser)
- The combination of SQLite's reliability + Datasette's interface is incredibly powerful

---

### SLIDE 5 — The Datasette Ecosystem

**Title:** It's Not Just Datasette — It's an Ecosystem

**Visual:** A hub-and-spoke diagram with Datasette at the center and tools radiating out: `sqlite-utils`, `csvs-to-sqlite`, `db-to-sqlite`, `datasette-vega`, `datasette-cluster-map`, `datasette-search-all`, `datasette-plot`, etc.

**Content/Talking Points:**
- **sqlite-utils** — Python library & CLI for creating and manipulating SQLite databases (this is the workhorse)
- **csvs-to-sqlite** — Convert CSV files directly into SQLite databases
- **db-to-sqlite** — Export from PostgreSQL, MySQL, or any SQLAlchemy-supported database to SQLite
- **Plugins** — Over 100 plugins for visualization, search, authentication, export formats, and more
- **Datasette Lite** — Datasette compiled to WebAssembly, runs entirely in the browser (no server needed!)
- The ecosystem means you're never starting from scratch — there's almost certainly a tool for your data format

**Links/Resources:**
- Datasette tools directory: [https://datasette.io/tools](https://datasette.io/tools)
- Datasette plugins directory: [https://datasette.io/plugins](https://datasette.io/plugins)
- sqlite-utils docs: [https://sqlite-utils.datasette.io/](https://sqlite-utils.datasette.io/)

---

### SLIDE 6 — CHPL: Who We Are (Context)

**Title:** Cincinnati & Hamilton County Public Library

**Visual:** Photo of the Main Library building. Key stats displayed as large, bold numbers.

**Content/Talking Points:**
- One of the busiest public library systems in the United States
- ~9.6 million volumes (13th largest library collection in the U.S., 2nd largest public library collection)
- 41 locations across Hamilton County
- Over 21 million items circulated annually (pre-pandemic peak)
- Downtown Main Library alone circulates over 4 million items/year — the most of any single library location in the country
- Runs the Sierra ILS (by Innovative Interfaces / Clarivate)
- A LOT of data. A LOT of staff who need to understand that data.

**Speaker Notes:**
- This context matters because it shows the scale of the problem — this isn't a small special library with a few thousand items
- The collection is massive, distributed across 41 locations, and constantly changing

---

### SLIDE 7 — The Architecture: How It All Fits Together

**Title:** The Pipeline: Sierra → SQL → SQLite → Datasette

**Visual:** A horizontal flow diagram with icons/logos at each step:

```
┌─────────┐    ┌──────────────┐    ┌──────────┐    ┌───────────┐    ┌──────────────┐
│  Sierra  │───▶│  PostgreSQL   │───▶│  Python   │───▶│  SQLite    │───▶│  Datasette    │
│   ILS    │    │  (Sierra DB)  │    │  Scripts  │    │  Database  │    │  Web Server   │
└─────────┘    └──────────────┘    └──────────┘    └───────────┘    └──────────────┘
                                       │                                     │
                                  sqlite-utils                        collection-analysis
                                  SQL queries                            .cincy.pl
```

**Content/Talking Points:**
- **Step 1: Export from Sierra** — Sierra exposes its data via a PostgreSQL database. We run SQL queries to extract snapshots of the collection (items, bibs, locations, statuses, circulation data)
- **Step 2: Transform with Python** — Python scripts + `sqlite-utils` reshape the data into clean SQLite tables with proper indexes
- **Step 3: Serve with Datasette** — Datasette serves the SQLite databases as an interactive web application
- Multiple date-stamped snapshots can be served simultaneously — enabling comparison over time
- The whole pipeline can be automated with cron jobs or scheduled tasks

**Links/Resources:**
- Sierra SQL examples: [https://github.com/plch](https://github.com/plch) (cincinnatilibrary GitHub org)
- Sierra SQL community: [https://github.com/jmgold/SQL-Queries](https://github.com/jmgold/SQL-Queries) (Jeremy Goldstein's collection)
- Collection-analysis repo: [https://github.com/cincinnatilibrary/collection-analysis](https://github.com/cincinnatilibrary/collection-analysis)

**Speaker Notes:**
- Emphasize that the SQL step is Sierra-specific, but the SQLite → Datasette pattern works for ANY ILS that lets you export data
- The `sierra-sql` repository from the CHPL GitHub org has a collection of useful queries

---

### SLIDE 8 — The Database Schema

**Title:** What's in the Database?

**Visual:** A simplified entity-relationship diagram or a table listing showing the key tables and their columns. Could also show a screenshot of the Datasette table list view.

**Content/Talking Points:**
- The `item` table is the heart of it — here's what a record looks like:
  - `item_record_num` (primary key)
  - `bib_record_num` (links to bibliographic record)
  - `barcode`
  - `location_code` (which branch/collection)
  - `item_format` (Book, DVD, Audiobook, etc.)
  - `item_status_code` (checked out, on shelf, missing, billed, etc.)
  - `checkout_date`, `due_date`, `last_checkout_date`, `last_checkin_date`
  - `checkout_total`, `renewal_total`
  - `item_callnumber`
  - `price_cents`
- Supporting tables for locations, formats, statuses, bibs
- Indexes are critical for performance — especially on columns you'll facet by

**Speaker Notes:**
- Walk through a single item record to make it concrete
- Point out the `item_view` — a denormalized view that joins item + bib data for easier querying
- Mention the CSV export capability shown at `collection-analysis.cincy.pl`

---

### SLIDE 9 — Live Demo: Exploring the Collection

**Title:** Demo Time! 🎉

**Visual:** Full-screen browser showing `collection-analysis.cincy.pl`. If doing a live demo, have backup screenshots ready.

**Demo Script / Talking Points (pick 3-4 to show):**

1. **Browse the item table** — Show the sheer scale (millions of rows), how Datasette handles pagination
2. **Facet by location** — Click `_facet=location_code` to see item counts per branch
3. **Facet by format** — Break down the collection by `item_format` (Juvenile Book, Large Print, DVD, etc.)
4. **Filter + Facet combo** — Filter to a single branch, then facet by format to see that branch's collection composition
5. **Facet by status** — Find items that are BILLED, MISSING, or IN TRANSIT
6. **Date faceting** — Use `_facet_date=last_checkin_date` to see activity patterns
7. **Cross-database queries** — Compare two snapshots from different dates
8. **SQL query editor** — Write a quick query: "How many items at Northside haven't circulated in 3+ years?"
9. **CSV export** — Show how any view can be exported as CSV for further analysis
10. **JSON API** — Append `.json` to any URL to get structured data back

**Speaker Notes:**
- If doing a live demo, have a specific "story" to tell: "Let's say the Northside branch manager wants to weed their juvenile nonfiction collection..."
- If NOT doing a live demo, prepare 4-5 high-quality screenshots that tell the same story
- Have the URL visible on screen so attendees can follow along on their own devices

---

### SLIDE 10 — Canned Queries: SQL for Non-SQL People

**Title:** Pre-Built Queries for Domain Experts

**Visual:** Screenshot showing Datasette's canned query interface — a named query with a description, parameter inputs, and results.

**Content/Talking Points:**
- Not everyone wants (or needs) to write SQL
- Datasette supports "canned queries" — pre-built SQL queries with human-readable names and descriptions
- You can add parameter inputs so users can customize the query without touching SQL
- Examples:
  - "Items at [branch] not checked out since [date]"
  - "Top circulating titles by [format] at [location]"
  - "Collection age distribution for [branch]"
- These are defined in the `metadata.yaml` configuration file
- Domain experts get the answers they need; IT/developers maintain the queries

**Speaker Notes:**
- This is often the "aha moment" for non-technical attendees
- Canned queries bridge the gap between "I can use a web form" and "I can write SQL"

---

### SLIDE 11 — The Hosting Story: $5/Month

**Title:** Hosting This Costs $5 a Month. Seriously.

**Visual:** A receipt or invoice-style graphic showing the cost breakdown. Or a Digital Ocean dashboard screenshot showing the $5/month droplet.

**Content/Talking Points:**
- Digital Ocean VPS (Droplet): **$5/month**
  - 1 vCPU, 1 GB RAM, 25 GB SSD
  - Ubuntu Linux
- Apache as reverse proxy (free)
- Let's Encrypt for TLS/HTTPS (free)
- Datasette + Python (free, open-source)
- DNS via Hover (cheap) → `collection-analysis.cincy.pl`
- Total ongoing cost: **$5/month** + domain registration
- The entire setup is documented step-by-step for other libraries to replicate

**Links/Resources:**
- Full hosting guide: [https://ils-underground.github.io/python_datasette_vps.html](https://ils-underground.github.io/python_datasette_vps.html)
- Datasette deployment docs: [https://docs.datasette.io/en/stable/deploying.html](https://docs.datasette.io/en/stable/deploying.html)

**Speaker Notes:**
- Walk through the key components: Digital Ocean droplet, Apache reverse proxy, Let's Encrypt, systemd for auto-restart
- Mention that this could also be done with Fly.io, Railway, Google Cloud Run, or even a Raspberry Pi
- The `ils-underground.github.io` guide is a community resource — other Sierra libraries are welcome to use and contribute

---

### SLIDE 12 — The Server Configuration

**Title:** What the Startup Script Looks Like

**Visual:** Code block showing the `start_datasette.sh` script (or a cleaned-up version of it). Syntax-highlighted, large font.

```bash
#!/bin/bash
venv/bin/datasette \
    --metadata=metadata.yaml \
    -i collection-2024-01-04.db \
    -i collection-2023-01-06.db \
    --crossdb \
    --setting hash_urls 1 \
    --setting default_page_size 100 \
    --setting sql_time_limit_ms 30000 \
    --setting allow_facet true \
    --setting num_sql_threads 20 \
    --setting base_url /home/ \
    --static static:static/ \
    --port 8010
```

**Content/Talking Points:**
- `-i` serves databases in immutable mode (read-only, enables aggressive caching)
- `--crossdb` allows SQL queries that JOIN across multiple database files
- `hash_urls` adds content hashes to URLs for cache-busting
- `sql_time_limit_ms` prevents runaway queries from blocking the server
- `base_url` lets Datasette live behind a reverse proxy at a subpath
- Custom CSS via `--static` for library branding
- All of this is in a simple bash script — no complex deployment pipeline

**Speaker Notes:**
- This is the ENTIRE deployment configuration. That's it.
- Mention the `metadata.yaml` file for setting titles, descriptions, source URLs, and canned queries
- The immutable mode + hash URLs pattern means you get essentially free CDN-like caching

---

### SLIDE 13 — Who Uses This and How?

**Title:** Putting Data in the Hands of Domain Experts

**Visual:** A grid of user personas with icons:
- 📚 Collection Development Librarian
- 🏠 Branch Manager
- 📊 Administration / Reporting
- 🔧 Technical Services
- 💻 IT / Development

**Content/Talking Points:**
- **Collection Development:** Analyzing age, condition, and circulation of materials to make purchasing and weeding decisions
- **Branch Managers:** Understanding their branch's collection composition, identifying gaps, tracking trends
- **Administration:** System-wide reporting, comparing branches, tracking KPIs
- **Technical Services:** Identifying cataloging issues, orphaned records, status anomalies
- **IT/Dev:** Using the JSON API to feed data into other applications, dashboards, or reports
- The common thread: **people who understand the collection can now directly interrogate the data**, without waiting for IT to run a report

**Speaker Notes:**
- Tell a specific story if you can: "One of our collection development librarians used this to identify $X worth of missing items at a specific branch" or similar
- Emphasize that the value isn't just in the tool — it's in the organizational shift of empowering domain experts

---

### SLIDE 14 — Beyond Collection Analysis: What Else Can You Datasette?

**Title:** Once You Have the Pattern, Everything Is a Dataset

**Visual:** A collage or grid showing different data sources that could become Datasette instances:
- ILS data (collection analysis) ✅
- Newspaper indexes (Newsdex) — teaser!
- Program attendance
- Room booking data
- Website analytics
- Vendor usage statistics
- Budget/purchasing data
- Community survey results

**Content/Talking Points:**
- The collection-analysis instance was just the beginning
- The same pattern (export → SQLite → Datasette) works for ANY structured data
- Teaser for Talk 2: "We also used this approach to liberate a century of Cincinnati newspaper index data — that's the Newsdex project, and I'll go deeper on that next"
- The barrier to entry is remarkably low: if you can get your data into a CSV, you can have a Datasette instance running in minutes

**Speaker Notes:**
- This is the "imagine the possibilities" moment
- If time permits, mention Datasette Lite (runs entirely in the browser via WebAssembly) as a zero-infrastructure option for experimenting

---

### SLIDE 15 — What's New in the Datasette World

**Title:** Datasette in 2025–2026: What's Happening

**Visual:** Screenshots or logos from recent Datasette developments.

**Content/Talking Points:**
- Datasette 1.0 alpha series — working toward a stable 1.0 release with a stable JSON API, plugin API, and template system
- **datasette-plot** — new visualization plugin (successor to datasette-vega)
- **datasette-comments** — collaborative annotation on data rows
- **datasette-extract** — use LLMs to extract structured data from unstructured text
- Simon Willison's NICAR 2026 workshop: "Coding agents for data analysis" — used Datasette alongside Claude Code and OpenAI Codex for data journalism workflows
- **Showboat + datasette-showboat** — new tools for coding agents to create and publish demonstrations
- The intersection of Datasette and AI/LLMs is a growing area — natural language to SQL, automated data exploration

**Links/Resources:**
- Simon Willison's newsletter: [https://simonw.substack.com/](https://simonw.substack.com/)
- Datasette newsletter: [https://datasette.substack.com/](https://datasette.substack.com/)
- Datasette Cloud blog: [https://www.datasette.cloud/blog/](https://www.datasette.cloud/blog/)

**Speaker Notes:**
- This slide shows the project is actively maintained and evolving
- The NICAR workshop is a great proof point — data journalists (a key Datasette audience) are using it alongside cutting-edge AI tools
- Mention that Simon is also the creator of the `llm` CLI tool, which pairs beautifully with Datasette for AI-powered data exploration

---

### SLIDE 16 — Getting Started: Your First Datasette in 5 Minutes

**Title:** Try It Yourself — It Takes 5 Minutes

**Visual:** Terminal screenshot or code block showing the commands. Large, readable font.

```bash
# Install
pip install datasette sqlite-utils

# Got a CSV? Make it a database.
sqlite-utils insert my-data.db my_table my-data.csv --csv

# Enable full-text search on a column
sqlite-utils enable-fts my-data.db my_table title description

# Launch Datasette
datasette my-data.db

# → Open http://localhost:8001/ in your browser
```

**Content/Talking Points:**
- Four commands. That's it.
- Works on Mac, Windows, Linux
- Also available via Homebrew: `brew install datasette`
- **Datasette Lite** — no install at all, runs in your browser: [https://lite.datasette.io/](https://lite.datasette.io/)
- Tutorials available at [https://datasette.io/tutorials](https://datasette.io/tutorials)

**Speaker Notes:**
- If time and wifi permit, you could actually DO this live — have a CSV ready and run through the commands
- Point people to the official tutorials, especially "Data analysis with SQLite and Python" from PyCon 2023

---

### SLIDE 17 — Resources & Thank You

**Title:** Resources

**Visual:** Clean, well-organized list of links. Consider a QR code that links to a page with all of these.

**Resources:**
- **Datasette:** [https://datasette.io/](https://datasette.io/)
- **Datasette Documentation:** [https://docs.datasette.io/](https://docs.datasette.io/)
- **sqlite-utils:** [https://sqlite-utils.datasette.io/](https://sqlite-utils.datasette.io/)
- **CHPL Collection Analysis (live):** [https://collection-analysis.cincy.pl/](https://collection-analysis.cincy.pl/)
- **Collection Analysis Source Code:** [https://github.com/cincinnatilibrary/collection-analysis](https://github.com/cincinnatilibrary/collection-analysis)
- **VPS Hosting Guide:** [https://ils-underground.github.io/python_datasette_vps.html](https://ils-underground.github.io/python_datasette_vps.html)
- **CHPL GitHub:** [https://github.com/cincinnatilibrary](https://github.com/cincinnatilibrary) / [https://github.com/plch](https://github.com/plch)
- **Datasette Tutorials:** [https://datasette.io/tutorials](https://datasette.io/tutorials)
- **Simon Willison's Blog:** [https://simonwillison.net/](https://simonwillison.net/)

**Speaker Notes:**
- Thank the audience
- Invite questions
- Mention that the Newsdex deep-dive talk is coming up next (if back-to-back)
- Offer to connect on GitHub or email for anyone who wants help getting started

---

## Design Notes for the Slide Deck

### Color Palette Suggestion
- **Primary:** CHPL brand blue (#0C2340 — from their footer CSS)
- **Accent:** Datasette's teal/green
- **Background:** White or very light gray
- **Code blocks:** Dark background with syntax highlighting (Monokai or similar)

### Typography
- **Headlines:** Bold sans-serif (e.g., Inter, Source Sans Pro, or Montserrat)
- **Body:** Clean sans-serif at readable sizes (18pt+ for body, 24pt+ for headlines)
- **Code:** Monospace (Fira Code, JetBrains Mono, or Source Code Pro)

### General Principles
- One idea per slide
- Minimal text — use the speaker notes for what you'll say
- Screenshots should be large and legible
- Every diagram should be simple enough to understand in 5 seconds
- Include the talk URL/QR code on the final slide so people can access all resources

---

## Timing Guide (approximate)

| Section | Slides | Est. Time |
|---------|--------|-----------|
| Intro + Problem | 1–2 | 2 min |
| Solution + Datasette intro | 3–5 | 3 min |
| CHPL context + Architecture | 6–8 | 3 min |
| Demo | 9–10 | 4 min |
| Hosting + Users | 11–13 | 3 min |
| What's next + Getting started | 14–16 | 3 min |
| Resources + Q&A | 17 | 2 min |
| **Total** | **17 slides** | **~20 min** |

> **Note:** This runs slightly over 15 minutes as designed — you have room to cut slides 5 (ecosystem), 12 (startup script), or 15 (what's new) to fit a tighter window.
