# Presentation 2: From Index Cards to SQLite — Liberating a Century of Cincinnati News with Datasette

**Target Length:** ~15 minutes (with extra material to edit down)
**Audience:** Library technologists, digital preservation / local history enthusiasts, Python developers, MARC/metadata specialists
**Prior Art:** [PyOhio 2021 Thunder Talk](https://www.pyohio.org/2021/program/talks/i-datasette-an-open-source-multi-tool-for-exploring-and-publishing-data/), [CHPL Blog: Newsdex Upgrade](https://chpl.org/blogs/post/newsdex-upgrade/)

---

## Slide-by-Slide Outline

---

### SLIDE 1 — Title Slide

**Title:** From Index Cards to SQLite: Liberating a Century of Cincinnati News with Datasette

**Subtitle:** The Newsdex Project — Transforming 100 years of librarian-curated newspaper indexing into an explorable dataset

**Visual:** A striking split-screen composition:
- **Left side:** The historic photo of the CHPL card catalog drawers (from the CHPL blog post)
- **Right side:** A screenshot of the Newsdex data in Datasette

This visual immediately tells the "before and after" story.

**Speaker Notes:**
- If this follows Talk 1: "In the last talk, I showed you how we use Datasette for collection analysis. Now I want to tell you a more specific story — about a dataset that stretches back almost 100 years."
- If standalone: Brief self-introduction + "This is a story about what happens when you combine decades of librarian expertise with modern open-source tools."

---

### SLIDE 2 — Chalmers Hadley's Vision (1927)

**Title:** "News reports of major local happenings would be matters of history some day"

**Visual:** The portrait photo of Chalmers Hadley from the CHPL blog post, displayed prominently. The quote as large text overlay. Include caption: "Chalmers Hadley, Head Librarian, CHPL (1924–1945)"

**Content/Talking Points:**
- In 1927, CHPL's Head Librarian Chalmers Hadley had an insight that would shape the library for the next century
- He directed staff to begin indexing local newspaper articles — creating a card for each article with its title, date, publication, page, column, and subject
- This was a deliberate act of preservation: treating ephemeral news as future historical record
- Librarians dutifully typed index cards and arranged them by subject for the next **65 years**

**Source:**
- [CHPL Blog: "CHPL's Newsdex Tool Just Made Researching Local History Even Easier" (May 2023)](https://chpl.org/blogs/post/newsdex-upgrade/)

**Speaker Notes:**
- Let this quote land. It's a beautiful articulation of the library's mission.
- The audience should feel the weight of almost a century of continuous, intentional effort by generations of librarians
- Contrast with how casually we think about data preservation today

---

### SLIDE 3 — The Card Catalog Era (1927–1992)

**Title:** 65 Years of Index Cards

**Visual:** The photograph of the physical card catalog from the CHPL blog post. If you have access to additional photos of the actual Newsdex card drawers, even better. Consider a timeline graphic:

```
1927 ──────────────────────────────────────────── 1992
 │                                                  │
 ▼                                                  ▼
Hadley begins                              Cards digitized
newspaper indexing                         into ILS as "Newsdex"

 ◄──── Librarians type index cards by hand ────►
```

**Content/Talking Points:**
- For 65 years, librarians hand-typed index cards for newspaper articles
- Each card captured: article title, newspaper name, date, page number, column number, subject headings, and whether an image accompanied the article
- Cards were arranged by subject in the catalog
- Coverage: Cincinnati Enquirer, Cincinnati Post, Cincinnati Herald, Cincinnati Magazine, Business Courier, Downtowner
- Selected coverage reaching back to the early 1800s
- This is a labor of love — generations of librarians contributing to a single, cumulative resource

**Speaker Notes:**
- Emphasize the human element: every card represents a librarian reading an article and deciding it was worth preserving a reference to
- The subject assignments are particularly valuable — they represent expert human classification, not automated tagging
- This kind of institutional knowledge is irreplaceable

---

### SLIDE 4 — The Digital Transition (1992)

**Title:** Newsdex Goes Digital

**Visual:** A screenshot of the current Newsdex search interface at `newsdex.cincinnatilibrary.org`, possibly alongside or transitioning from the card catalog photo. Show the search example from the CHPL blog post — the "1937 flood" search result.

**Content/Talking Points:**
- In the early 1990s, the library's card catalog was computerized
- The decision was made to also computerize the newspaper index cards
- In March 1992, the newspaper index became "Newsdex" — available online on library computers
- Today: [https://newsdex.cincinnatilibrary.org/](https://newsdex.cincinnatilibrary.org/)
- Newsdex provides citations — not full text — pointing you to where articles can be found in digitized newspaper databases
- A search for "1937 flood" returns a citation telling you the article appeared in the Cincinnati Enquirer on January 26, 1937, page 7, column 2, with a picture
- Staff continue to add entries, including retroactive indexing of articles from before 1900

**Links/Resources:**
- Newsdex: [https://newsdex.cincinnatilibrary.org/](https://newsdex.cincinnatilibrary.org/)
- CHPL Blog Post (with video tutorial): [https://chpl.org/blogs/post/newsdex-upgrade/](https://chpl.org/blogs/post/newsdex-upgrade/)

**Speaker Notes:**
- Walk through a search example to make it concrete
- Explain the citation format: "7:2 pic" means page 7, column 2, with a picture
- Note that Newsdex is freely accessible — no library card required
- The blog post includes a video tutorial on basic searching — great resource for attendees

---

### SLIDE 5 — The Question: What Else Can We Do With This Data?

**Title:** A Century of Structured Metadata — What If We Could Really Explore It?

**Visual:** A thought-bubble or lightbulb slide. Simple and clean. Perhaps a mockup showing the kinds of questions you might want to ask:

- "What subjects were most covered in the 1930s vs. the 1960s?"
- "How many obituaries are indexed per decade?"
- "Which newspapers have the most coverage in Newsdex?"
- "What was Cincinnati reading about during the Great Depression?"
- "Can I browse all articles tagged with 'floods' or 'baseball'?"

**Content/Talking Points:**
- The traditional Newsdex search interface is great for finding specific articles
- But what if you wanted to **explore** the dataset as a whole?
- What if you wanted to see patterns, distributions, trends across time?
- What if you wanted to facet by newspaper, decade, or subject?
- What if you wanted to run SQL queries against a century of local journalism metadata?
- To do that, we need to get the data out of MARC and into something more flexible

**Speaker Notes:**
- This is the pivot point of the talk — from "here's what exists" to "here's what we built"
- Frame it as: the existing interface serves one use case (known-item search) very well. Datasette serves a completely different use case (exploration and discovery).

---

### SLIDE 6 — The Challenge: MARC Records

**Title:** The Data Format: MARC (MAchine-Readable Cataloging)

**Visual:** A side-by-side showing:
- **Left:** A raw MARC record (or a simplified representation of one) — showing numbered fields, subfield codes, indicators
- **Right:** The same data as a clean, human-readable table row

Consider something like:

```
MARC Record:                          What a human wants:
─────────────                         ──────────────────
245 10 $a Relief agencies             Title: Relief agencies move swiftly
       move swiftly                   Newspaper: Cincinnati Enquirer
260    $b Cincinnati Enquirer         Date: 1937-01-26
       $c 1937-01-26                  Page: 7
300    $a 7:2 pic                     Column: 2
650  0 $a Floods                      Image: Yes
650  0 $a Emergency management        Subjects: Floods; Emergency management
```

**Content/Talking Points:**
- MARC is the international standard for bibliographic data — created in the 1960s by the Library of Congress
- It's a binary format with numbered fields (245 = title, 260 = publication info, 650 = subject headings, etc.)
- Fields have indicators and subfield codes ($a, $b, $c, etc.)
- MARC is powerful and precise, but it's:
  - Not human-readable
  - Not easily queryable
  - Not designed for the kind of ad-hoc exploration we want
- The Newsdex MARC records sit in the GitHub repo as a full export: `2023-01-24_newsdex-full-marc-export.zip`

**Links/Resources:**
- Newsdex GitHub repo: [https://github.com/cincinnatilibrary/newsdex](https://github.com/cincinnatilibrary/newsdex)
- MARC standards (Library of Congress): [https://www.loc.gov/marc/](https://www.loc.gov/marc/)

**Speaker Notes:**
- Don't go too deep into MARC arcana — the audience needs to understand that it's structured but opaque
- The key point is: MARC is a serialization format designed for library catalog interchange, not for data analysis
- Joke opportunity: "MARC is one of those formats that's been described as 'write-only' — you can create it, but reading it back requires a PhD in library science"

---

### SLIDE 7 — The Conversion Pipeline: Overview

**Title:** MARC → Python → SQLite → Datasette

**Visual:** A clean pipeline diagram similar to Talk 1, but specific to Newsdex:

```
┌──────────────┐    ┌──────────┐    ┌──────────────┐    ┌───────────┐    ┌──────────┐
│  MARC Export  │───▶│  pymarc  │───▶│  Field       │───▶│  SQLite   │───▶│ Datasette │
│  (.mrc file)  │    │  (Python) │    │  Mapping &   │    │  Database │    │          │
│              │    │          │    │  Cleanup     │    │          │    │          │
└──────────────┘    └──────────┘    └──────────────┘    └───────────┘    └──────────┘
                                         │
                                    Jupyter Notebooks:
                                    • marc-to-sqlite.ipynb
                                    • newsdex-convert.ipynb
                                    • notes_and_mappings.ipynb
```

**Content/Talking Points:**
- The entire pipeline lives in the GitHub repo as Jupyter notebooks
- Three key notebooks:
  1. **`notes_and_mappings.ipynb`** — Documents which MARC fields map to which human-readable columns (the "translation layer")
  2. **`newsdex-convert.ipynb`** — Reads the MARC file and converts records to structured data
  3. **`marc-to-sqlite.ipynb`** — Loads the structured data into a SQLite database
- Python library: **pymarc** — the standard Python library for reading/writing MARC records
- The output: a clean SQLite database ready for Datasette

**Links/Resources:**
- Newsdex repo (all notebooks): [https://github.com/cincinnatilibrary/newsdex](https://github.com/cincinnatilibrary/newsdex)
- pymarc: [https://pypi.org/project/pymarc/](https://pypi.org/project/pymarc/)

**Speaker Notes:**
- Emphasize that the Jupyter notebooks serve as both code AND documentation — anyone can read them to understand the process
- The `notes_and_mappings` notebook is arguably the most important — it's where domain expertise from librarians meets programming

---

### SLIDE 8 — Reading MARC with pymarc

**Title:** Step 1: Reading MARC Records with Python

**Visual:** A code block showing actual (or representative) code from the notebooks. Syntax-highlighted, large font.

```python
from pymarc import MARCReader

with open('newsdex-full-marc-export.mrc', 'rb') as fh:
    reader = MARCReader(fh)
    for record in reader:
        # Title (MARC field 245)
        title = record['245']['a'] if record['245'] else None

        # Publication info (MARC field 260)
        newspaper = record['260']['b'] if record['260'] else None
        date = record['260']['c'] if record['260'] else None

        # Page/column info (MARC field 300)
        physical = record['300']['a'] if record['300'] else None

        # Subject headings (MARC field 650, repeatable!)
        subjects = []
        for field in record.get_fields('650'):
            subjects.append(field['a'])

        print(f"{title} | {newspaper} | {date} | {subjects}")
```

**Content/Talking Points:**
- **pymarc** makes it straightforward to iterate over MARC records and extract fields
- Each MARC field is accessed by its number (245, 260, 300, 650, etc.)
- Subfields are accessed by their letter code ($a, $b, $c)
- Some fields are **repeatable** (like 650 for subject headings) — a single record can have many subjects
- The tricky parts:
  - Not all records have all fields
  - Date formats are inconsistent across decades of data entry
  - Some fields have content in unexpected subfields
  - Character encoding issues from legacy data

**Speaker Notes:**
- Walk through the code line by line if time permits
- Point out the defensive coding pattern: `if record['245'] else None` — because not every record has every field
- The repeatable fields (subjects) are particularly interesting — they represent the librarians' classification work

---

### SLIDE 9 — The Translation Layer: Field Mapping

**Title:** Step 2: The Translation Layer (Where Librarian Expertise Meets Code)

**Visual:** A mapping table showing MARC fields → human-readable columns. This could be a styled table or a screenshot from the `notes_and_mappings.ipynb` notebook.

| MARC Field | Subfield | Becomes... | Notes |
|------------|----------|------------|-------|
| 245 | $a | `title` | Article title |
| 260 | $b | `newspaper` | Publication name |
| 260 | $c | `date` | Publication date (needs normalization!) |
| 300 | $a | `page`, `column`, `has_image` | Needs parsing: "7:2 pic" → page=7, col=2, image=true |
| 650 | $a | `subjects` (JSON array) | Repeatable — one record may have many subjects |
| 100 | $a | `author` | Author/byline (when available) |
| 500 | $a | `notes` | General notes |
| 008 | positions 7-10 | `year` | Fixed-length date field for sorting/faceting |

**Content/Talking Points:**
- This mapping is the **most critical part** of the entire pipeline
- It requires understanding of BOTH the MARC standard AND the specific practices used by Newsdex catalogers over the decades
- The `notes_and_mappings.ipynb` notebook documents this in detail
- Special parsing challenges:
  - The "physical description" field (300) contains page, column, AND image indicator in a single string — needs regex or custom parsing
  - Dates are entered in multiple formats across different eras of data entry
  - Subject headings use Library of Congress Subject Headings (LCSH) vocabulary — rich and standardized, but sometimes inconsistent

**Speaker Notes:**
- This is the slide where you make the case that this work CANNOT be done by a developer alone
- The librarians who created and maintained Newsdex are essential collaborators — they understand the cataloging conventions, the edge cases, the evolution of practices over time
- Tell a story about a specific mapping challenge you encountered and how a librarian helped resolve it

---

### SLIDE 10 — Building the SQLite Database

**Title:** Step 3: Into SQLite with sqlite-utils

**Visual:** Code block showing the database creation, followed by a screenshot of the resulting table structure in Datasette.

```python
import sqlite_utils

db = sqlite_utils.Database("newsdex.db")

# Insert records
db["articles"].insert_all(records, pk="record_id")

# Enable full-text search on title and subjects
db["articles"].enable_fts(["title", "subjects", "notes"])

# Create indexes for columns we'll want to facet on
db["articles"].create_index(["newspaper"])
db["articles"].create_index(["year"])
```

**Content/Talking Points:**
- **sqlite-utils** makes it trivial to go from Python dictionaries to a well-structured database
- Key decisions at this stage:
  - **Primary key:** What uniquely identifies a Newsdex record?
  - **Full-text search:** Which columns should be searchable? (title, subjects, notes)
  - **Indexes:** Which columns will users want to facet or filter on? (newspaper, year, subject)
  - **Repeating fields:** How to handle subjects? Options: JSON array column (enables Datasette's "facet by JSON array"), separate junction table, or denormalized text
- The resulting SQLite database is a single file — portable, self-contained, and ready for Datasette

**Speaker Notes:**
- Show the actual size of the resulting database file — it's probably surprisingly small
- Mention that SQLite's full-text search (FTS5) is incredibly powerful — it supports phrase searches, boolean operators, and ranking
- The choice of JSON arrays for subjects is deliberate — Datasette has a built-in "facet by JSON array" feature

---

### SLIDE 11 — Newsdex in Datasette: Demo

**Title:** The Result: A Century of Cincinnati News, Explorable

**Visual:** Full-screen browser showing the Newsdex data in Datasette. If live demo, have backup screenshots. Show multiple views:

**Demo Script / Screenshots (pick 4-5):**

1. **The articles table** — Show the total record count. Scroll through to see the variety of dates and topics.
2. **Full-text search: "1937 flood"** — Show how Datasette's search finds all articles related to the Great Flood of 1937
3. **Facet by newspaper** — See the distribution across Cincinnati Enquirer, Post, Herald, etc.
4. **Facet by year or decade** — See how coverage changes over time. What years have the most entries?
5. **Facet by subject** — Browse the most common subjects. What did Cincinnati care about most?
6. **Search for obituaries** — Show how a genealogist might use this: search for a family name, find death notices with dates and page numbers
7. **Combined filters** — Filter to Cincinnati Post + 1940s + subject "World War" to see wartime coverage
8. **JSON API** — Show the `.json` endpoint for any view — other applications could build on this data
9. **Compare with traditional Newsdex** — Side-by-side: the original search interface finds a specific article, Datasette lets you explore the *shape* of the entire collection

**Speaker Notes:**
- The demo should tell a story: "Let's say a local historian is researching how Cincinnati newspapers covered the civil rights movement..."
- Or: "A genealogist is looking for any mention of the Voelker family in Cincinnati newspapers..."
- Emphasize what you CAN'T do with the traditional interface that you CAN do with Datasette: aggregate views, faceted browsing, time-based exploration, subject distribution analysis

---

### SLIDE 12 — What the Data Reveals: Visualizations and Patterns

**Title:** Seeing Patterns in a Century of News

**Visual:** This is an opportunity for a really compelling data visualization slide. Options:

- **Timeline chart:** Number of Newsdex entries per year, showing how coverage grows over time. Spike during major events (1937 flood, WWII, etc.)
- **Newspaper distribution pie/bar chart:** Which newspapers account for the most entries?
- **Subject word cloud or bar chart:** Most common subjects across the entire collection
- **Heat map:** Coverage density by decade × newspaper

These could be generated with Datasette plugins (datasette-vega, datasette-plot) or externally with matplotlib/Plotly from the SQLite data.

**Content/Talking Points:**
- Once the data is in Datasette, you can start seeing patterns that were invisible before
- Example findings (customize with your actual data):
  - "The Cincinnati Enquirer accounts for X% of all Newsdex entries"
  - "Coverage peaks in the 1930s–1950s, reflecting the golden age of local journalism"
  - "Obituaries and death notices make up X% of the total — Newsdex is a major genealogical resource"
  - "'Floods' appears as a subject in X records, clustered around 1884, 1913, 1937, and 1997"
- These insights were always latent in the data — but they were invisible when it was locked in MARC records or a keyword-search-only interface

**Speaker Notes:**
- If you have time to pre-generate some visualizations, this slide can be a real showstopper
- Even simple bar charts of "entries per decade" or "top 20 subjects" tell a powerful story
- Consider using a Datasette plugin like `datasette-vega` or `datasette-plot` to create these interactively during the demo

---

### SLIDE 13 — The CHPL Blog Post: Telling the Story to the Public

**Title:** Sharing the Story with Our Community

**Visual:** A browser screenshot of the CHPL blog post: [https://chpl.org/blogs/post/newsdex-upgrade/](https://chpl.org/blogs/post/newsdex-upgrade/) — showing the headline, the Hadley photo, and the card catalog image.

**Content/Talking Points:**
- In May 2023, the Genealogy & Local History Department published a blog post telling the Newsdex story
- It covers the full history: 1927 origins, the card catalog era, the 1992 digitization, and the modern search interface
- Includes a video tutorial on using Newsdex
- This blog post is a great model for how to communicate technical/data work to a public audience
- The historical photos (Hadley portrait, card catalog) are invaluable — they make the story tangible
- Key detail: "A library card with us is not necessary to use Newsdex" — this is genuinely open data

**Links/Resources:**
- CHPL Blog Post: [https://chpl.org/blogs/post/newsdex-upgrade/](https://chpl.org/blogs/post/newsdex-upgrade/)
- Newsdex: [https://newsdex.cincinnatilibrary.org/](https://newsdex.cincinnatilibrary.org/)

**Speaker Notes:**
- Feature this blog post prominently — it's the "primary source" for the Newsdex narrative
- The blog post demonstrates something important: the work of opening data isn't just technical — it's also about storytelling and communication
- Encourage attendees to read the post and watch the tutorial video

---

### SLIDE 14 — Lessons Learned

**Title:** What We Learned Along the Way

**Visual:** Clean slide with key takeaways. Could use icons or simple graphics for each point. Avoid a wall of text — these are conversation starters, not comprehensive statements.

**Lessons:**

1. **Domain expertise is irreplaceable**
   - The MARC-to-SQLite conversion required deep understanding of cataloging conventions built up over decades
   - Developers and librarians working together produces far better results than either alone

2. **"Good enough" ships; "perfect" doesn't**
   - Not every MARC field maps cleanly. Some dates are messy. Some records are incomplete.
   - Get the data out there and iterate — don't wait for a flawless dataset

3. **The presentation layer matters**
   - The same data in MARC vs. in Datasette tells completely different stories
   - Facets and full-text search change what questions people think to ask

4. **Historical data has compounding value**
   - Every year that passes, the older entries in Newsdex become more valuable
   - Making this data explorable increases its value to genealogists, historians, journalists, and the community

5. **Open source + small budgets = powerful things**
   - pymarc, sqlite-utils, Datasette — all free, all open source
   - The entire pipeline runs on commodity hardware

**Speaker Notes:**
- Share personal anecdotes for each lesson if possible
- Lesson 1 is the most important — this is a collaboration story, not a solo developer story
- Lesson 2 is liberating for anyone who's been paralyzed by the scale of their data cleanup task

---

### SLIDE 15 — Connecting the Dots: The Bigger Picture

**Title:** The Pattern: Data Liberation Through Open Source

**Visual:** A diagram showing both projects (Collection Analysis and Newsdex) feeding into the same Datasette platform:

```
┌─────────────────┐      ┌───────────┐
│  Sierra ILS      │─────▶│           │
│  (Collection     │      │           │
│   Snapshots)     │      │ Datasette │──▶ Branch Managers
└─────────────────┘      │ Platform  │──▶ Collection Dev Librarians
                          │           │──▶ Genealogists
┌─────────────────┐      │           │──▶ Local Historians
│  MARC Export     │─────▶│           │──▶ Researchers
│  (Newsdex        │      │           │──▶ The Public
│   Newspaper      │      │           │
│   Index)         │      └───────────┘
└─────────────────┘           │
                              │
                         $5/month
                         Open source
                         Community-documented
```

**Content/Talking Points:**
- Two very different datasets — live ILS snapshots and a century of newspaper index records
- Both served through the same tool, same infrastructure, same self-service model
- The pattern is general: **if you can get your data into SQLite, Datasette can make it explorable**
- This isn't just a CHPL story — any library sitting on structured data can do this
- Possible future Datasette instances:
  - Program attendance and event data
  - Digital collection metadata
  - Interlibrary loan statistics
  - Community survey responses
  - Patron feedback data (anonymized)

**Speaker Notes:**
- This is the "call to action" — invite the audience to think about what data THEY are sitting on
- The technical barrier is low; the organizational barrier (getting buy-in, finding time) is the real challenge
- Mention the ILS Underground community as a resource for Sierra libraries specifically

---

### SLIDE 16 — What's Next for Newsdex + Datasette?

**Title:** Where Do We Go From Here?

**Visual:** A roadmap-style graphic or a "future possibilities" brainstorm. Could be illustrated with mockup screenshots.

**Possible Future Directions:**

- **Datasette Lite for Newsdex** — Serve the entire Newsdex SQLite database via WebAssembly in the browser — zero server needed, anyone can explore it from anywhere
  - Link: [https://lite.datasette.io/](https://lite.datasette.io/)

- **Direct linking to digitized articles** — Where full-text digitized versions exist in ProQuest or other databases, could we deep-link from Newsdex citations?

- **LLM-powered search** — Use the `datasette-query-assistant` plugin or similar to allow natural-language questions: "What was happening in Cincinnati during the 1918 flu pandemic?"

- **Geocoding** — Many Newsdex articles reference specific Cincinnati locations. Could we geocode and map them using `datasette-cluster-map`?

- **Community contributions** — Could the public help identify corrections or additions to Newsdex metadata?

- **Linking Newsdex to collection data** — Cross-reference newspaper coverage with items in the library's collection (books about the same topics, by the same people, etc.)

- **Automated visualization** — Use coding agents (like the approach from Simon Willison's NICAR 2026 workshop) to vibe-code interactive visualizations on top of the Newsdex data

**Speaker Notes:**
- These are aspirational — you don't have to commit to any of them
- Datasette Lite is particularly exciting because it removes the server entirely
- The LLM angle is worth mentioning given the current moment — Datasette + AI is an active area of development

---

### SLIDE 17 — Getting Involved: Resources and Community

**Title:** Resources & How to Get Involved

**Visual:** Organized resource list with icons/logos. QR code linking to a central resource page.

**Newsdex Resources:**
- **Newsdex (live search):** [https://newsdex.cincinnatilibrary.org/](https://newsdex.cincinnatilibrary.org/)
- **CHPL Blog Post — Newsdex History:** [https://chpl.org/blogs/post/newsdex-upgrade/](https://chpl.org/blogs/post/newsdex-upgrade/)
- **Newsdex GitHub Repo (MARC data + notebooks):** [https://github.com/cincinnatilibrary/newsdex](https://github.com/cincinnatilibrary/newsdex)
- **CHPL Genealogy & Local History:** [https://chpl.org/genealogy-history/](https://chpl.org/genealogy-history/)

**Datasette Resources:**
- **Datasette:** [https://datasette.io/](https://datasette.io/)
- **Datasette Documentation:** [https://docs.datasette.io/](https://docs.datasette.io/)
- **sqlite-utils:** [https://sqlite-utils.datasette.io/](https://sqlite-utils.datasette.io/)
- **pymarc:** [https://pypi.org/project/pymarc/](https://pypi.org/project/pymarc/)
- **Datasette Tutorials:** [https://datasette.io/tutorials](https://datasette.io/tutorials)

**CHPL Technical Resources:**
- **Collection Analysis (live):** [https://collection-analysis.cincy.pl/](https://collection-analysis.cincy.pl/)
- **CHPL GitHub:** [https://github.com/cincinnatilibrary](https://github.com/cincinnatilibrary)
- **ILS Underground (hosting guide):** [https://ils-underground.github.io/python_datasette_vps.html](https://ils-underground.github.io/python_datasette_vps.html)
- **Presentations archive:** [https://rayvoelker.github.io/](https://rayvoelker.github.io/)

**Speaker Notes:**
- Thank the audience
- Thank the Genealogy & Local History Department — they created the data over nearly 100 years
- Thank Simon Willison and the Datasette community
- Invite questions
- If at a conference, offer to do a hands-on demo at a hallway table or BoF session

---

### SLIDE 18 — Thank You / Q&A

**Title:** Thank You!

**Visual:** Simple, clean. Your name, contact info, and the QR code. Perhaps the split-screen card catalog / Datasette image from the title slide again as a bookend.

**Content:**
- Your name, title, and institution
- GitHub: rayvoelker / cincinnatilibrary
- Email or preferred contact method
- Presentation materials link (if you publish them)

---

## Design Notes for the Slide Deck

### Color Palette Suggestion
- **Primary:** A warm, archival tone — deep navy (#0C2340 from CHPL brand) or a rich brown/sepia to evoke the historical angle
- **Accent:** Datasette teal/green for the "modern" sections
- **The visual story:** Slides about the past (cards, Hadley, MARC) could use warmer tones; slides about the present/future (Datasette, code, demos) could use cooler, more modern tones. This creates a visual arc.

### Typography
- **Headlines:** Bold serif for historical sections (e.g., Playfair Display, Merriweather) transitioning to sans-serif for technical sections
- **Body/Code:** Same as Talk 1 — clean sans-serif, monospace for code

### Photography & Images
- The CHPL blog post photos (Hadley portrait, card catalog) are essential — get high-resolution versions if possible
- Screenshots should be large, annotated with arrows or highlights to draw attention to specific features
- Consider a recurring "then vs. now" visual motif throughout

### General Principles
- This talk has a stronger narrative arc than Talk 1 — lean into the storytelling
- The code slides should be readable but don't need to be exhaustive — link to the notebooks for full details
- The demo (Slide 11) is the emotional climax — it's where the audience sees the payoff of 100 years of work

---

## Timing Guide (approximate)

| Section | Slides | Est. Time |
|---------|--------|-----------|
| Intro + Historical narrative | 1–4 | 4 min |
| The question + MARC challenge | 5–6 | 2.5 min |
| Pipeline + Code walkthrough | 7–10 | 4 min |
| Demo + Visualizations | 11–12 | 4 min |
| Blog post + Lessons | 13–14 | 2.5 min |
| Big picture + Future | 15–16 | 2.5 min |
| Resources + Q&A | 17–18 | 2 min |
| **Total** | **18 slides** | **~21 min** |

> **Note:** This runs over 15 minutes as designed — you have room to trim. Candidates for cutting:
> - Slide 8 (pymarc code) — could be summarized verbally with a link to the notebook
> - Slide 12 (visualizations) — impressive but optional if you haven't pre-generated the charts
> - Slide 16 (what's next) — could be condensed to 2-3 bullet points on the "big picture" slide
> - The MARC explanation (Slide 6) could be shortened if the audience already knows MARC

---

## Appendix: Additional Slide Ideas (If Time Permits or for Extended Version)

### BONUS SLIDE A — The Newsdex Data Model

A more detailed look at the SQLite schema for the Newsdex database:

```sql
CREATE TABLE articles (
    record_id INTEGER PRIMARY KEY,
    title TEXT,
    newspaper TEXT,
    date TEXT,
    year INTEGER,
    page TEXT,
    column_num TEXT,
    has_image BOOLEAN,
    author TEXT,
    subjects TEXT,  -- JSON array
    notes TEXT,
    marc_leader TEXT,
    raw_marc BLOB   -- preserve the original for fidelity
);

CREATE INDEX idx_articles_newspaper ON articles(newspaper);
CREATE INDEX idx_articles_year ON articles(year);

-- Full-text search
CREATE VIRTUAL TABLE articles_fts USING fts5(
    title, subjects, notes,
    content=articles, content_rowid=record_id
);
```

### BONUS SLIDE B — pymarc Deep Dive

More detailed code showing edge cases: handling missing fields, date normalization, parsing the "page:column pic" format, and dealing with character encoding issues.

### BONUS SLIDE C — The Sierra SQL Community

A shout-out to the Sierra ILS SQL community — the `ils-underground` documentation site, Jeremy Goldstein's SQL query collection, and the broader ecosystem of Sierra users sharing code. This work doesn't happen in isolation.

### BONUS SLIDE D — Datasette Lite Demo

A live demonstration of loading the Newsdex SQLite database into Datasette Lite — proving that you can explore this data with zero infrastructure, entirely in the browser.

### BONUS SLIDE E — Other Libraries Doing Similar Work

Examples of other libraries, archives, or cultural institutions using Datasette or similar approaches to make their data explorable. Could mention Bellingcat (investigative journalism), Philip James's Oakland/Alameda city council minutes project, or other use cases from the Datasette community.
